let uname = 'Anil',  
	udivision = 'First';  
	   
	let user = {  
	   uname,  
	   udivision  
	};  
	console.log(user.uname);  
	console.log(user.udivision);  
    
    
    // emp object 
    var department = 'dep_name';  
    
    
    var emp = {  
        id : 102,  
        name : 'Anil',  
        [department]:'Production'  
    }  
    console.log(emp);  

    //concise method 

    let user1 = {  
        firstName : "Sunil",  
        lastName : "Kumar",  
        fullName(){  
            return this.firstname + " " + this.lastName;  
        }  
    };  


    let customer={
        id :"101",
        name:"Ram",
        email:"ram@gmail.com"
    }

    console.log(customer.id + "  "+customer.name+"   "+customer.email)

    let customer1 =new Object();
    customer1.id=201;
    customer1.name="raj";
    customer1.email="raj@gmail.com";

    console.log(customer1.id+"  "+customer1.name+"  "+customer1.email)
