	"use strict"

    let colors = ['Red', 'Yellow'];  
	let newColors = [...colors, 'Violet', 'Orange', 'Green'];  
    var sizes=['L','S','M']
    var list=[...sizes]
	console.log(newColors,...sizes);  
    console.log(list)
