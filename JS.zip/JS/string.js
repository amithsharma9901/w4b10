var globalVar = "abc";  //var - global let  -local, const - cannot be redefined
const pi=3.142;
// Parent self invoking function
(function outerFunction (outerArg) { // begin of scope outerFunction
  // Variable declared in outerFunction function scope
  var outerFuncVar = 'x';    
  // Closure self-invoking function
  (function innerFunction (innerArg) { // begin of scope innerFunction
    // variable declared in innerFunction function scope
    var innerFuncVar = "y";
    let x=10;
    x=x+20;
    globalVar="bbc";
    console.log(         
      "outerArg = " + outerArg + "\n" +
      "outerFuncVar = " + outerFuncVar + "\n" +
      "innerArg = " + innerArg + "\n" +
      "innerFuncVar = " + innerFuncVar + "\n" +
      "globalVar = " + globalVar+
    "x="+x);
  // end of scope innerFunction
  })(5); // Pass 5 as parameter

  console.log(globalVar)
 // console.log(x);
// end of scope outerFunction
})(7); // Pass 7 as parameter
//pi=478.99;
console.log(pi)
console.log(globalVar)