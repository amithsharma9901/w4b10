var num = new Array(5); // This single numeric value indicates the size of array.  
var i;  
for(i=0;i<num.length;i++){  
num[i]=i*5;  
console.log(num[i]);  
}  

var num1=20
var str1="abc"
var bool1=true
var num2=null

console.log(typeof(num1))
console.log(typeof(bool1))


var today=new Date()
var x="987"
console.log(parseInt(x))
console.log(x.toString())
name1="JSuser123"
name2=new String("JsUSer1234")
console.log(name1.length)
console.log(name2.toUpperCase())
console.log(Math.random())
console.log(Math.max(45,78))