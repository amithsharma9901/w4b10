

function table(){
  for(x=1;x<=10;x++) {
   document.writeln("<br>"+ 5 +" X"+ x +"="+5*x);
 }
  var y=1;
  while(y<=10) {
   document.writeln("<br>"+ 5 +" X"+ y +"="+5*y);
   y++;
 }


}