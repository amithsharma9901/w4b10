
console.log("ES6 programming")
/*
i=1;
while( i<=5){
    console.log(i);
    if(i==3) 
       break;
   
   i++;
}
console.log("for ...");
for(i=0;i<=10;i++)
    console.log(i)

*/

sayHello()
var a=[3,4,5,6,7,8];
for(i=0;i<a.length;i++)
    console.log(a[i])

for( var x in a)
    console.log(x)

for( var y of a)
    console.log(y)

	function Mobile(model_no){  
       	this.Model = model_no;  
    	this.Color = 'White';  
    	this.RAM = '4GB';  
        this.qty=10;
        this.price=9999.99;
    }  
    	var Samsung = new Mobile("Galaxy");  
    	for(var k in Samsung)  
    	{  
    	console.log(k+ " : " +Samsung[k]);  
    	}  
    
        var courses=['java','javascript','css','react']
        for(var c of courses)
            console.log(c)

j=1;
while(j<=10) {
    console.log(j);
    j++;
}

    i=1
    do {
        console.log(i);
        i++;
    } while(i<=10);


    	var x = 5; /* 101 */  
	var y = 7; /*     111 */  
	var res = 0;  
	  
	console.log("Value of 5 in binary 0100 0110" );  
	console.log("Value of 7 in binary 0101 0000" );  
	  
	  
	res = x | y;       
	console.log("Value of x | y = %d\n", res );  


    p1=100
    p2=20
    result=(p1>p2)?"p1 is big": "p2 is big";
    console.log(result);

    function sum1(a,b=9){  //named function
        return a+b;
    }
    console.log('sum='+sum1(4,5))
    console.log('sum='+sum1(8))

    var f2= function(){  //annaymous function
        console.log('Ananymous function')
    }
    f2()
    var f1 = (a,b) =>  a*a+b*b;  //arrow function
    console.log(f1(4,6))


    function abc(a,...b){  //var args... multiple args
        console.log(a,b);
    }
    console.log(abc(10,2))
    console.log(abc(10,2,3,4,12,34,56,78))
    console.log(abc(10,29,653,454,234))
    
    	function* show() {  
    	yield 100;  
        yield;
        yield 200;
    	}  
        
        var s=show()
        console.log(s.next())
        console.log(s.next())
        console.log(s.next())
    
   

    function sayHello() {
        console.log('Welcome message')
    }
//destructuring
    	var colors = ["Violet", "Indigo"]
        var [a,b]=colors 
        console.log(a+"   "+b)
