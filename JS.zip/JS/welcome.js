

function welcome(){
    alert("Welcome to JS");
}