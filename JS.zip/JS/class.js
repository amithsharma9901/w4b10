/*Using the class declaration */

class Customer{
   
    constructor(name1, email1){
     this.name1="user123";
     this.email1="user@gmail.com";
    }
   disp= ()=>{
        console.log(this.name1+"  "+this.email1)
    }
}

var c1=new Customer();
  //c1.getCustomerDetails();
  c1.disp();
/*
class Foo
{
    constructor(){
        console.log("Foo constructor invoked");
    }
    sayHi(){
        return "Hi from Foo";
    }
}
let foo = new Foo();	
console.log(foo.sayHi());



//foo = new Foo();			
console.log("Foo's type : "+typeof Foo);
console.log("foo instance of Foo Type");
console.log(foo instanceof Foo);
console.log(foo.sayHi());
console.log("foo.sayHi === Foo.prototype.sayHi");
console.log(foo.sayHi+" "+Foo.prototype.sayHi);


//Using the class expression 
let Baz = class{
    greet(){
        return "Greetings from Baz-greet";
    }
}
let baz = new Baz();
console.log(baz.greet());


*/