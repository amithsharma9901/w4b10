class Employee{
    constructor(){
     console.log("welcome);
    }

    show(){
        console.log("show method");

    };
    disp=()=>{ console.log("disp function");

  }


}

var a=new Employee();
a.show();
a.disp();