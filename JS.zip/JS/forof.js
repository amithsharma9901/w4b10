var departments = ["Training","HR","BPO"];
		for(var department of departments){
			console.log(department);
		}


		var name="Ayushi";
		 var bonus=5000;

		console.log(`Name of the CG Employee: ${name} Bonus=  ${bonus*2}   `);