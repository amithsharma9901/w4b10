 function fun1() {
 var namelength=document.f.sname.value.length;
                 if(namelength<5)
                  alert( "name cannot be lessthan 5 character");
                 
                
               }