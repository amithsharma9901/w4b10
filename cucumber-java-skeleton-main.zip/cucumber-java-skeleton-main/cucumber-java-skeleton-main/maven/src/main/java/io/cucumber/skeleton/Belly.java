package io.cucumber.skeleton;

public class Belly {
    public void eat(int cukes) {
    	System.out.println(" step started");
    }
    
    public void waitStep() {
    	System.out.println(" waiting after step1");
    }
    
    public void endProcess() {
    	System.out.println(" all steps completed");
    }
    
}
