package com.var.springboot_mongodbdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootMongodbdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
