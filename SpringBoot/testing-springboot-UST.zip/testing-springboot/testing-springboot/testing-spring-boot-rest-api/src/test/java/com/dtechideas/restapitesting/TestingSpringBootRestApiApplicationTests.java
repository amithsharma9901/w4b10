package com.dtechideas.restapitesting;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestingSpringBootRestApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
