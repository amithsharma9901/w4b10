package com.var.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.var.entity.Customer;
import com.var.entity.Product;
import com.var.repository.CustomerRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class CustomerService {
	
	@Autowired
	CustomerRepository customerRepository;
	
	public void addCustomer(Customer customer) {
		customerRepository.save(customer);//insert
	}
	
	public List<Customer> getAllCustomers() {
		return (List)customerRepository.findAll();//select
	}
	public Customer getCustomer(Integer id) {
		return customerRepository.findById(id).get(); //select id 
	}
	public void  deleteCustomer(Integer id) {
		 customerRepository.deleteById(id);  //commit, rollback   delete from where id=
	}
	public void  updateCustomer(Integer id,Customer customer1) {
		 Customer customer=customerRepository.findById(id).get();
		customer.setName(customer1.getName());
	}


}
