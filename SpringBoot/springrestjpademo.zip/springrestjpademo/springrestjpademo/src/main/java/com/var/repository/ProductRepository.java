package com.var.repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.var.entity.Product;

@Repository
public interface ProductRepository  extends CrudRepository<Product,Integer>{
	// save, findById(), findAll,deleteById,deleteAll
	//Optional<Product> findByQuantity(Integer qty);
	//Optional<Product> findByName(String name);
	//Optional<Product> findByPrice(Integer price);
	
	//  @Query("SELECT p.name FROM Product p WHERE p.qty=:qty")
	//	String findNameByQty(@Param("qty") String emailId);

}


/*
Optional<Product> findByQty(Integer qty);

Optional<Product> findByQtyAndPrice(Integer qty,Integer price);

List<Product> findByQtyOrPrice(Integer qty,Integer price);

List<Product> findByQtyLessThan(Integer qty);

List<Product> findByPriceGreaterThan(Integer price);

List<Product> findByNameNull();
List<Product> findByNameNotNull();

List<Product> findByNameLike(String pattern);


List<Product> findByNameOrderByQty(Integer qty);

List<Product> findByNameOrderByPriceDesc(String name);




    @Query("SELECT p.name FROM Product p WHERE p.qty=:qty")
	String findNameByQty(@Param("qty") String emailId);

	@Query("UPDATE Product p SET p.qty = :qty WHERE p.id=:id")
	@Modifying
	@Transactional
	Integer updateProductQty(@Param("qty") Integer qty, @Param("id") Integer id);

	@Query("DELETE FROM Product p WHERE p.qty=:qty")
	@Modifying
	@Transactional
	Integer deleteProductByQty(@Param("qty") Integer qty);

*/