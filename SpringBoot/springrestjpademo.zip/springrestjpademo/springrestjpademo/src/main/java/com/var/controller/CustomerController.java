package com.var.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.var.entity.Customer;

import com.var.service.CustomerService;

@RestController
public class CustomerController {
	@Autowired
	CustomerService customerService;
	
	@PostMapping("/customer")
	public ResponseEntity<String>  addCustomer(@RequestBody Customer customer)
	{
		customerService.addCustomer(customer);
		return new ResponseEntity("Added",HttpStatus.CREATED);
	}
	@GetMapping("/customer/{id}")
	public Customer getCustomer(@PathVariable("id") Integer id) {
		return customerService.getCustomer(id);
		
	}
	@GetMapping("/customer")
	public List<Customer> getAllCustomers() {
		return customerService.getAllCustomers();
		
	}
	@PutMapping("/customer/{id}")
	public String updateCustomer(@PathVariable("id") Integer id,@RequestBody Customer customer) {
		 customerService.updateCustomer(id,customer);
		 return "updated";
		
	}
	@DeleteMapping("/customer/{id}")
	public String deleteCustomer(@PathVariable("id") Integer id) {
		 customerService.deleteCustomer(id);
		 return "deleted";
		
	}
	

}
