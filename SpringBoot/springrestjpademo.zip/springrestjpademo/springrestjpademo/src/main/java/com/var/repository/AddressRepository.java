package com.var.repository;

import org.springframework.data.repository.CrudRepository;

import com.var.entity.Address;

public interface AddressRepository  extends CrudRepository<Address,Integer> {

}
