package com.evernoth.SpringBotWebApp1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBotWebApp1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
