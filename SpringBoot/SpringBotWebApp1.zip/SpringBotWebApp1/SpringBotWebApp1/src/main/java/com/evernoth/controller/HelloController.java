package com.evernoth.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {
	
	@GetMapping("/hello")
	public String getMassage() {
		return " Hello";
	}
	
	@GetMapping("/welcomeust")
	public String welcome() {
		return "Welcome to SpringREST";
	}
	
	@PostMapping("/addust")
	public ResponseEntity<String>  add() {
		return new ResponseEntity("added",HttpStatus.CREATED);
		
	}
	@DeleteMapping("/deleteust")
	public ResponseEntity<String> delete() {
		return new ResponseEntity("deleted",HttpStatus.CREATED);
	}
	@PutMapping("/updateust")
	public ResponseEntity<String> update() {
		return new ResponseEntity("updated",HttpStatus.CREATED);
	}

}
