package com.evernoth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBotWebApp1Application {
	public static void main(String[] args) {
		SpringApplication.run(SpringBotWebApp1Application.class, args);
	}

}
