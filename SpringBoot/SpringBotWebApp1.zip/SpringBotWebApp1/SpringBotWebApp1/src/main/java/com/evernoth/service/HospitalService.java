package com.evernoth.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.evernoth.model.Hospital;
import com.evernoth.repository.HospitalRepository;

@Service
public class HospitalService {
	@Autowired
	HospitalRepository hospitalRepository;
	
	public void addHospital(Hospital hospital) {
		
		hospitalRepository.addHospital(hospital);
		
	}
	public List<Hospital> returnHospitals(){
		return hospitalRepository.returnHospitals();
	}
	public void listHospitals() {
		hospitalRepository.listHospitals();
	}
	//
}
