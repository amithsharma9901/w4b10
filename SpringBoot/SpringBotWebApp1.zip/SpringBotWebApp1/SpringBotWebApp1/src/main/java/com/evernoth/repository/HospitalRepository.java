package com.evernoth.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.evernoth.model.Hospital;

@Repository
public class HospitalRepository {
	
	static ArrayList<Hospital> hlist=new ArrayList<>();
	
   public void addHospital(Hospital hospital) {
	   hlist.add(hospital);
   }
   
   public void listHospitals() {
	   hlist.forEach(h->System.out.println(h));
   }
   public List<Hospital> returnHospitals() {
	   return hlist;
   }
	
}
