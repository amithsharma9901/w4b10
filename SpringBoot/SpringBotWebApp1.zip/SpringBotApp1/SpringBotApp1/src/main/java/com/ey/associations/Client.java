package com.ey.associations;



import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

public class Client {
	@PersistenceContext
	static private EntityManager entityManager; //entities  detached 
	

	public static void main(String[] args) {
		
		
		
		Student student = new Student();
		student.setName("Deepak Patil");
		Address homeAddress = new Address();
		homeAddress.setStreet("MG Road");
		homeAddress.setCity("Pune");
		homeAddress.setState("Maharashtra");
		homeAddress.setZipCode("411 017");
		
		//inject address into student
		student.setAddress(homeAddress);
		
		//persist only student, no need to persist Address explicitly
		entityManager.persist(student);
		
		
		
		System.out.println("Added one student with address to database.");
		
	}
}
